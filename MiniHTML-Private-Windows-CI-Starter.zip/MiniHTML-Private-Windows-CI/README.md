# MiniHTML — private Windows build setup

This package contains the MiniHTML source and a GitHub Actions workflow that compiles it on a Windows Server 2022 runner using the Visual Studio 2022 x64 MSVC toolchain.

## Keep the repository private

Create a **Private** repository on GitHub, then upload these files without changing their paths. Do not switch repository visibility to Public.

## Build

The workflow runs when `MiniHTML.cpp` or the workflow itself is pushed to the `main` branch. It can also be started manually from **Actions → MiniHTML Windows MSVC build → Run workflow**.

The workflow uses:

- `windows-2022` GitHub-hosted runner
- Visual Studio 2022 MSVC x64
- `/std:c++17 /EHsc /utf-8 /O2`
- Win32, GDI+, WinHTTP, Common Controls and Shlwapi system libraries

On success, download the `MiniHTML-Windows-x64` artifact from the workflow run. The artifact is retained for 7 days. The workflow does not publish a Release or make the repository public.

## Usage control

Only the Windows build job runs; there are no test matrices or repeated jobs. Manual runs are available so builds can be controlled. Check **GitHub → Settings → Billing and licensing → Usage** to monitor Actions usage. Private-repository minutes depend on the account's current plan and runner multipliers.

## Important

A successful compile confirms that MSVC produced the executable; it does not by itself prove that every website or browser feature works at runtime. The runner is headless, so interactive GUI testing still needs a Windows desktop session.
